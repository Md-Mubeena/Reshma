package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.AdminDAO;
import com.cg.dao.IAdminDAO;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;
import com.sun.jndi.ldap.Connection;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	static final Logger LOGGER = Logger.getLogger(AgentServlet.class);
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getSession().getAttribute("username") == null) {
			LOGGER.info("Username is null, Session not established");
			response.sendRedirect("index.jsp");
		}
			
		else {
		if(request.getSession().getAttribute("rolecode").equals("agnt")){
			LOGGER.info("Logged in as agent, redirecting to agent's home page");
			response.sendRedirect("agentHomePage.jsp");
    	}
    	else if(request.getSession().getAttribute("rolecode").equals("adm")){
    		LOGGER.info("Logged in as admin, redirecting to admin's home page");
    		response.sendRedirect("adminHomePage.jsp");
    	}
    	else if(request.getSession().getAttribute("rolecode").equals("usr")){
    		LOGGER.info("Logged in as user, redirecting to agent's home page");
    		response.sendRedirect("userHomePage.jsp");
    	}
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		
		PrintWriter writer = response.getWriter();
		
		//fetching parameters from login form
		String username = request.getParameter("uname");
		String password = request.getParameter("pass");
		
	
		IAdminDAO adminDAO = new AdminDAO();
		writer.println("<html><body>");
		UserRole userDTO = new UserRole(username,password);

		RequestDispatcher dispatcher = null;

		try {
			if (adminDAO.validate(userDTO).equals("adm")) {
				//Establishing session
				HttpSession session = request.getSession();
				session.setAttribute("username",userDTO.getUserName());
				session.setAttribute("rolecode","adm");
				LOGGER.info(username+"logged in");
				dispatcher = request.getRequestDispatcher("adminHomePage.jsp");
				dispatcher.forward(request, response);
			} else if (adminDAO.validate(userDTO).equals("usr")) {
				HttpSession session = request.getSession();
				session.setAttribute("username",userDTO.getUserName());
				session.setAttribute("rolecode","usr");
				LOGGER.info(username+"logged in");
				dispatcher = request.getRequestDispatcher("userHomePage.jsp");
				dispatcher.forward(request, response);
			} else if (adminDAO.validate(userDTO).equals("agnt")) {
				HttpSession session = request.getSession();
				session.setAttribute("username",userDTO.getUserName());
				session.setAttribute("rolecode","agnt");
				LOGGER.info(+username+"logged in");
				dispatcher = request.getRequestDispatcher("agentHomePage.jsp");
				dispatcher.forward(request, response);
			}

			else {

				writer.println("<h1><font color ='red'>Invalid credentials,Try again</font></h1> ");
				dispatcher = request.getRequestDispatcher("index.jsp");
				dispatcher.include(request, response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			LOGGER.warn("Error in LoginServlet ");
			response.sendRedirect("Error.jsp");
			System.out.println(e.getMessage()+" exception in login servlet");
		} 

		writer.println("</html></body>");
	}
	
}
