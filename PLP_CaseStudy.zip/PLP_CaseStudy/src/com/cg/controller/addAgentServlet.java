package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.AgentDAO;
import com.cg.dao.IAgentDAO;
import com.cg.dao.IUserDAO;
import com.cg.dao.UserDAO;
import com.cg.dto.UserRole;
import com.cg.exception.ICRException;

@WebServlet("/addAgent")
public class addAgentServlet extends HttpServlet {
	@Override
	static final Logger LOGGER = Logger.getLogger(AddAgentServlet.class);
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		if (request.getSession().getAttribute("username") == null) {
			response.sendRedirect("index.jsp");

		} else {
			if (request.getSession().getAttribute("rolecode").equals("usr")) {
				LOGGER.info("Redirected to user home page");
				response.sendRedirect("userHomePage.jsp");
			} else if (request.getSession().getAttribute("rolecode").equals("agnt")) {
				LOGGER.info("Redirected to agent home page");
				response.sendRedirect("agentHomePage.jsp");
			}
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		try {
			String userName = request.getParameter("uname");
			String password = request.getParameter("pwd");
			String roleCode = request.getParameter("rolecode");

			UserRole agentDTO = new UserRole(userName, password, roleCode);
			out.println("<html><body>");
			int rows = 0;
			IAgentDAO agent = new AgentDAO();

			rows = agent.addAgent(agentDTO);
			if (rows > 0) {
				LOGGER.info("agent has been added");
				out.println("<h2>Agent succesfully added, please wait while redirecting to homepage</h2>");
				response.setHeader("Refresh", "2;url=adminHomePage.jsp");
			} else if (rows == -1)
				LOGGER.info("agent has not been added");
				response.sendRedirect("AdminError.jsp");
			else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Problem while adding agent, Please try again!');");
				out.println("location='addAgent.jsp';");
				out.println("</script>");
			}
		} catch (Exception e) {
			LOGGER.warn("Error in add Agent servlet");
			response.sendRedirect("AdminError.jsp");
			System.out.println(e.getMessage() + " exception in addAgent servlet");
		}
		out.println("</html></body>");
	}
}
