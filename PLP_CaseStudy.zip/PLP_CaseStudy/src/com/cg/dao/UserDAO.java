package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.CreateClaim;
import com.cg.dto.User;
import com.cg.exception.ICRException;
import com.cg.utiliy.JdbcUtility;

public class UserDAO implements IUserDAO{

	@Override
	public int addUser(User userDTO) throws ICRException {
		
		Connection connection = null;
		PreparedStatement ps = null;
		int Error = -1;
		int rows= 0;
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection established");

			ps = connection.prepareStatement(QueryConstants.ADDROLE);
			ps.setString(1,userDTO.getUserName());
			ps.setString(2, userDTO.getPassword());
			ps.setString(3, userDTO.getRoleCode());
			ps.executeUpdate();
			System.out.println("rows"+rows);
			
			ps = connection.prepareStatement(QueryConstants.ADDACCOUNTNUMBER);
			ps.setLong(1, userDTO.getAccountNumber());
			ps.setString(2, userDTO.getUserName());
			rows = ps.executeUpdate();
			System.out.println("rows"+rows);
			
	}catch(ICRException | SQLException e) {
		LOGGER.error("exception in user DAO");
		return Error;
		//throw new ICRException(e.getMessage()+"problem occured in adduser DAO");
	}
		return rows;
}

	@Override
	public int createClaim(CreateClaim createClaim) throws ICRException {
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int rows= 0;
		int Error = -1;
		try {
			connection = JdbcUtility.getConnection();
			LOGGER.info("Connection established");

			ps = connection.prepareStatement(QueryConstants.ADDCLAIM);
			ps.setString(1,createClaim.getReason());
			ps.setString(2,createClaim.getLocation());
			ps.setString(3, createClaim.getCity());
			ps.setString(4, createClaim.getState());
			ps.setInt(5,createClaim.getZip());
			ps.setString(6,createClaim.getClaimType());
			ps.setInt(7,createClaim.getPolicyNo());
			 rows = ps.executeUpdate();
			System.out.println("rows"+rows);
			
			
			ps = connection.prepareStatement(QueryConstants.GETCLAIMNO);
			ps.setInt(1,createClaim.getPolicyNo());
			rs = ps.executeQuery();
			rs.next();
			int claimNo = rs.getInt("claimno");
			
			ps = connection.prepareStatement(QueryConstants.ADDSTATUS);
			ps.setInt(1,claimNo);
			ps.setString(2,"pending");
			rows = ps.executeUpdate();
			System.out.println("rows"+rows);
			
		
	}catch(ICRException | SQLException e) {
		LOGGER.error("exception in user DAO");
		return Error;
		//throw new ICRException(e.getMessage()+"problem occured in creating claim , userDao");
	}
		return rows;
}

	
	
}